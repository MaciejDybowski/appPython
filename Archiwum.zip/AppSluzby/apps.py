from django.apps import AppConfig


class AppsluzbyConfig(AppConfig):
    name = 'AppSluzby'
